// Acts as Data Transfer Object (DTO) or Result Object
public class Transaction {

    private boolean overdraft;

    private boolean excessDeposit;

    private int numberOfDeposits = 0;

    private double interestEarned;

    public boolean isOverdraft() {
        return overdraft;
    }

    public void setOverdraft(boolean overdraft) {
        this.overdraft = overdraft;
    }

    public boolean isExcessDeposit() {
        return excessDeposit;
    }

    public void setExcessDeposit(boolean excessDeposit) {
        this.excessDeposit = excessDeposit;
    }

    public int getNumberOfDeposits() {
        return numberOfDeposits;
    }

    public void deposit() {
        numberOfDeposits++;
    }

    public void setInterestEarned(double interestEarned) {
        this.interestEarned = interestEarned;
    }

    public double getInterestEarned() {
        return interestEarned;
    }
}
