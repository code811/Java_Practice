// Model
public class Savings extends Account {

    public final double MINIMUM_BALANCE = 500.00;

    public final double OVERDRAFT_FEE = 10.00;

    public final double EXCESSIVE_TRANSACTION_FEE = 10.00;

    public final double INTEREST = (1.5) / 100;

    public final Transaction transaction = new Transaction();

    public Savings(double accountBalance) {
        super(accountBalance);
    }

    @Override
    public double withdraw(double withdrawAmount) {
        super.withdraw(withdrawAmount);

        if(getAccountBalance() < MINIMUM_BALANCE) {
            super.withdraw(OVERDRAFT_FEE);
            transaction.setOverdraft(true);
        }

        if(getAccountBalance() > MINIMUM_BALANCE) {
            transaction.setOverdraft(false);
        }

        return getAccountBalance();
    }

    @Override
    public double deposit(double depositAmount) {
        super.deposit(depositAmount);
        transaction.deposit();

        final int MAX_TRANSACTIONS = 5;
        if(transaction.getNumberOfDeposits() > MAX_TRANSACTIONS) {
            this.withdraw(EXCESSIVE_TRANSACTION_FEE);
            transaction.setExcessDeposit(true);
        }

        return getAccountBalance();
    }

    public double addInterest() {
        double netBalance = getAccountBalance() * INTEREST;
        super.deposit(netBalance);
        transaction.setInterestEarned(netBalance);
        return getAccountBalance();
    }

    @Override
    public String toString() {
        return "Savings Account #" + getAccountNumber() + ", balance $" + getAccountBalance();
    }
}
