public class Account {

    private int accountNumber;

    private static int nextNumber = 10001;

    private double accountBalance;

    public Account() {
        accountNumber = nextNumber;
        nextNumber++;
        accountBalance = 0;
    }

    public Account(double accountBalance) {
        accountNumber = nextNumber;
        nextNumber++;
        this.accountBalance = accountBalance;
    }

    public double withdraw(double withdrawAmount) {
        return accountBalance -= withdrawAmount;
    }

    public double deposit(double depositAmount) {
        return accountBalance += depositAmount;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    @Override
    public String toString() {
        return "Account #" + accountNumber + " , balance $" + accountBalance;
    }
}
