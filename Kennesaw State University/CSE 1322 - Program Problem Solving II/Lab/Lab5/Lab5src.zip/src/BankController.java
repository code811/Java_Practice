// Acts as controller
public class BankController {

    private final Checking checking;

    private final Savings savings;

    private final BankUI UI;

    public BankController(Checking checking, Savings savings, BankUI UI) {
        this.checking = checking;
        this.savings = savings;
        this.UI = UI;
    }

    public void run() {
        BankUI.printHeader();
        int option = 0;
        do {
            option = UI.promptMenu();
            doOption(option);
        } while(option != 8);
    }

    private void doOption(int option) {
        switch(option) {
            case 1 -> withdrawFromChecking();
            case 2 -> withdrawFromSavings();
            case 3 -> depositToChecking();
            case 4 -> depositToSavings();
            case 5 -> UI.printBalanceChecking();
            case 6 -> UI.printBalanceSaving();
            case 7 -> awardInterest();
            case 8 -> UI.printQuit();
            default -> UI.printInvalid();
        }
    }

    private void withdrawFromChecking() {
        double withdrawAmount = UI.promptWithdrawChecking();
        checking.withdraw(withdrawAmount);

        if(checking.transaction.isOverdraft()) {
            UI.printCheckingOverdraft(checking.MINIMUM_BALANCE, checking.OVERDRAFT_FEE);
        }
        UI.printCurrentBalanceChecking();
    }

    private void withdrawFromSavings() {
        double withdrawAmount = UI.promptWithdrawSavings();
        savings.withdraw(withdrawAmount);

        if(savings.transaction.isOverdraft()) {
            UI.printSavingsOverdraft(savings.MINIMUM_BALANCE, savings.OVERDRAFT_FEE);
        }
        UI.printCurrentBalanceSavings();
    }

    private void depositToChecking() {
        double depositAmount = UI.promptDepositToChecking();
        checking.deposit(depositAmount);
        UI.printCurrentBalanceChecking();
    }

    public void depositToSavings() {
        double depositAmount = UI.promptDepositToSavings();
        savings.deposit(depositAmount);
        UI.printNumOfDeposits(savings.transaction.getNumberOfDeposits());

        if(savings.transaction.isExcessDeposit()) {
            UI.printExcessTransactions(savings.EXCESSIVE_TRANSACTION_FEE);
        }
        UI.printCurrentBalanceSavings();
    }

    public void awardInterest() {
        savings.addInterest();
        UI.printAwardInterest(savings.transaction.getInterestEarned());
    }
}
