// Model
public class Checking extends Account {

    public final double MINIMUM_BALANCE = 0.00;

    public final double OVERDRAFT_FEE = 20.00;

    public final Transaction transaction = new Transaction();

    public Checking(double accountBalance) {
        super(accountBalance);
    }

    @Override
    public double withdraw(double withdrawAmount) {
        super.withdraw(withdrawAmount);

        if(getAccountBalance() < MINIMUM_BALANCE) {
            super.withdraw(OVERDRAFT_FEE);
            transaction.setOverdraft(true);
        }

        if(getAccountBalance() > MINIMUM_BALANCE) {
            transaction.setOverdraft(false);
        }

        return getAccountBalance();
    }

    @Override
    public String toString() {
        return "Checking Account #" + getAccountNumber() + ", balance $" + getAccountBalance();
    }
}