public class Main {
    public static void main(String[] args) {
        Checking checking = new Checking(0.00);
        Savings savings = new Savings(500.00);
        BankUI ui = new BankUI(checking, savings);
        BankController controller = new BankController(checking, savings, ui);

        controller.run();
    }
}